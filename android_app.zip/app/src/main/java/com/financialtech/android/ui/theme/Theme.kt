package com.financialtech.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3B82F6),
    background = Color(0xFF0B0F14),
    surface = Color(0xFF0F141B),
    onPrimary = Color(0xFFFFFFFF),
    onBackground = Color(0xFFE6EDF6),
    onSurface = Color(0xFFE6EDF6),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    background = Color(0xFFF7F9FC),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color(0xFFFFFFFF),
    onBackground = Color(0xFF0B0F14),
    onSurface = Color(0xFF0B0F14),
)

@Composable
fun FinancialTechTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = androidx.compose.material3.Typography(),
        content = content,
    )
}
