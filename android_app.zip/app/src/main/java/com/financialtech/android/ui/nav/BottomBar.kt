package com.financialtech.android.ui.nav

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState

@Composable
fun BottomBar(navController: NavHostController) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val current = backStackEntry?.destination?.route

    val items = listOf(
        NavItem("Import", Routes.IMPORT, Icons.Outlined.VideoLibrary),
        NavItem("Edit", Routes.EDITOR, Icons.Outlined.Edit),
        NavItem("Captions", Routes.CAPTIONS, Icons.Outlined.ClosedCaption),
        NavItem("Export", Routes.EXPORT, Icons.Outlined.Download),
    )

    NavigationBar(
        containerColor = Color(0xFF0B0F14),
        contentColor = Color(0xFFE6EDF6),
    ) {
        items.forEach { item ->
            val selected = current == item.route
            NavigationBarItem(
                selected = selected,
                onClick = {
                    navController.navigate(item.route) {
                        launchSingleTop = true
                    }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF3B82F6),
                    selectedTextColor = Color(0xFF3B82F6),
                    unselectedIconColor = Color(0xFFA7B0BE),
                    unselectedTextColor = Color(0xFFA7B0BE),
                    indicatorColor = Color(0xFF111B2A),
                )
            )
        }
    }
}

private data class NavItem(
    val label: String,
    val route: String,
    val icon: ImageVector,
)
