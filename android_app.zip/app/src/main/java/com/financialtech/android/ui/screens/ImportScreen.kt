package com.financialtech.android.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.financialtech.android.ui.nav.Routes

@Composable
fun ImportScreen(navController: NavHostController) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Financial Tech", style = MaterialTheme.typography.headlineMedium)
        Text("CapCut-like offline shorts generator (Android)", style = MaterialTheme.typography.bodyMedium)

        Button(
            modifier = Modifier.padding(top = 16.dp),
            onClick = {
                // TODO: implement picking a local video using Activity Result APIs.
                navController.navigate(Routes.EDITOR)
            }
        ) {
            Text("Import Video")
        }
    }
}
