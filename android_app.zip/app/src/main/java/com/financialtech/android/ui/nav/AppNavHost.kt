package com.financialtech.android.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.financialtech.android.ui.screens.CaptionsScreen
import com.financialtech.android.ui.screens.EditorScreen
import com.financialtech.android.ui.screens.ExportScreen
import com.financialtech.android.ui.screens.ImportScreen

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Routes.IMPORT) {
        composable(Routes.IMPORT) { ImportScreen(navController) }
        composable(Routes.EDITOR) { EditorScreen(navController) }
        composable(Routes.CAPTIONS) { CaptionsScreen(navController) }
        composable(Routes.EXPORT) { ExportScreen(navController) }
    }
}
