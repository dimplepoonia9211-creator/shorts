package com.financialtech.android.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.financialtech.android.ui.nav.AppNavHost
import com.financialtech.android.ui.nav.BottomBar

@Composable
fun AppRoot() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = { BottomBar(navController = navController) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding: PaddingValues ->
        Surface(modifier = Modifier.fillMaxSize().padding(padding)) {
            AppNavHost(navController = navController)
        }
    }
}
