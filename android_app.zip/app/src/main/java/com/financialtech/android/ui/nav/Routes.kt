package com.financialtech.android.ui.nav

object Routes {
    const val IMPORT = "import"
    const val EDITOR = "editor"
    const val CAPTIONS = "captions"
    const val EXPORT = "export"
}
