package com.financialtech.android.processing

object CaptionService {
    // TODO: integrate whisper.cpp (JNI) and model download.
    // For now this is a placeholder API.
    fun transcribe(inputPath: String, language: String?): String {
        return ""
    }
}
